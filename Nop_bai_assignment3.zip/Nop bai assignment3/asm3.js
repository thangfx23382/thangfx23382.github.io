"use strict";
// ẨN thông tin cá nhân
const submitbtn = document.querySelector(".submit1");
const thongtincn = document.querySelector(".ttcn");
const formtongquat = document.querySelector(".form-nhaplieu");

const email = document.getElementById("email").value;
const EmailError = document.querySelector(".emailError");

submitbtn.addEventListener("click", function () {
  console.log("vaoday");
  const email = document.getElementById("email").value;

  if (!email) {
    EmailError.textContent = "Hãy nhập email";
    EmailError.classList.remove("hide");
    console.log(email);
  } else if (isValidEmail(email) && !formtongquat.classList.contains("hide")) {
    formtongquat.classList.add("hide");
    thongtincn.classList.remove("hide");
    console.log(email);
  } else EmailError.textContent = "Định dạng không hợp lệ";
  console.log(EmailError);
  EmailError.classList.remove("hide");
});
function isValidEmail(email) {
  const regex =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return regex.test(String(email).toLowerCase());
}

// Ân thông tin nội dung nghề nghiệp
// const viewbtn = document.querySelector(".view-more");
// const viewlessbtn = document.querySelector(".view-less");

// console.log(gethover.length);

// function gothover() {
//   viewbtn.classList.remove("viewmore-btn-hidden");
// }
// function ungethover() {
//   if (!viewbtn.classList.contains("viewmore-btn-hidden"))
//     viewbtn.classList.add("viewmore-btn-hidden");
// }

// const gethover = document.querySelectorAll(".cot");
// gethover.forEach(function (cot) {
//   const Hoverbtn = cot.querySelector(".view-more");

//   function gothover() {
//     Hoverbtn.classList.remove("viewmore-btn-hidden");
//   }
//   function ungethover() {
//     if (!Hoverbtn.classList.contains("viewmore-btn-hidden"))
//       Hoverbtn.classList.add("viewmore-btn-hidden");
//   }
//   for (let i = 0; i < gethover.length; i++) {
//     gethover[i].addEventListener("mouseover", gothover);
//     gethover[i].addEventListener("mouseleave", ungethover);
//   }
// });
const hienthi = document.querySelectorAll(".cot");
const dulieu = document.querySelector(".dulieu");
const viewbtn = document.querySelector(".view-more");
const viewlessbtn = document.querySelector(".view-less");
function ungetInfor() {
  viewlessbtn.classList.add("viewless-btn-hidden");

  dulieu.classList.add("hidden");
}
function getInfor() {
  if (!viewbtn.classList.contains("viewless-btn-hidden")) {
    viewbtn.classList.add("viewless-btn-hidden");
  }

  dulieu.classList.remove("hidden");

  viewlessbtn.classList.remove("viewless-btn-hidden");
  console.log("alo");
}
console.log(hienthi.length);
console.log(hienthi);
viewbtn.addEventListener("click", getInfor);
viewlessbtn.addEventListener("click", ungetInfor);
